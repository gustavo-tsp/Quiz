#ifndef MATHLIB_H
#define MATHLIB_H

int add(int a, int b);
long factorial(int n);
int is_prime(int n);
double average(const double *values, int length);

#endif
