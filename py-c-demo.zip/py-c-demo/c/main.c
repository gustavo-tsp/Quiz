#include <stdio.h>
#include "mathlib.h"

int main(void) {
    double notas[] = {7.5, 8.0, 9.5, 6.0};

    printf("add(2, 3)      = %d\n", add(2, 3));
    printf("factorial(5)   = %ld\n", factorial(5));
    printf("is_prime(17)   = %d\n", is_prime(17));
    printf("average(notas) = %.2f\n", average(notas, 4));
    return 0;
}
