#include "mathlib.h"

int add(int a, int b) {
    return a + b;
}

long factorial(int n) {
    if (n < 0) return -1;
    long result = 1;
    for (int i = 2; i <= n; i++) result *= i;
    return result;
}

int is_prime(int n) {
    if (n < 2) return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

double average(const double *values, int length) {
    if (length <= 0) return 0.0;
    double sum = 0.0;
    for (int i = 0; i < length; i++) sum += values[i];
    return sum / length;
}
