from mathlib import add, factorial, is_prime, average


def main():
    print("add(2, 3)      =", add(2, 3))
    print("factorial(5)   =", factorial(5))
    print("is_prime(17)   =", is_prime(17))
    print("average(notas) =", round(average([7.5, 8.0, 9.5, 6.0]), 2))


if __name__ == "__main__":
    main()
