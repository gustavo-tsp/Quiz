"""Wrapper Python para a biblioteca C (via ctypes)."""
import ctypes
import os
import sys

_BASE = os.path.dirname(os.path.abspath(__file__))
_EXT = {"win32": "dll", "darwin": "dylib"}.get(sys.platform, "so")
_LIB_PATH = os.path.join(_BASE, "..", "build", f"libmathlib.{_EXT}")

try:
    _lib = ctypes.CDLL(_LIB_PATH)
except OSError as exc:
    raise RuntimeError(
        "Biblioteca C não encontrada. Rode make na raiz do projeto primeiro."
    ) from exc

_lib.add.argtypes = [ctypes.c_int, ctypes.c_int]
_lib.add.restype = ctypes.c_int

_lib.factorial.argtypes = [ctypes.c_int]
_lib.factorial.restype = ctypes.c_long

_lib.is_prime.argtypes = [ctypes.c_int]
_lib.is_prime.restype = ctypes.c_int

_lib.average.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.c_int]
_lib.average.restype = ctypes.c_double


def add(a: int, b: int) -> int:
    return _lib.add(a, b)


def factorial(n: int) -> int:
    result = _lib.factorial(n)
    if result < 0:
        raise ValueError("n deve ser >= 0")
    return result


def is_prime(n: int) -> bool:
    return bool(_lib.is_prime(n))


def average(values) -> float:
    values = list(values)
    arr = (ctypes.c_double * len(values))(*values)
    return _lib.average(arr, len(values))
